﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.Security.AccessControl;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Threading;
using System.Security.Principal;


namespace WinApp
{
    public partial class SharingRights : Form
    {
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool LogonUser(string
        lpszUsername, string lpszDomain, string lpszPassword,
        int dwLogonType, int dwLogonProvider, ref
IntPtr phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private unsafe static extern int FormatMessage(int
        dwFlags, ref IntPtr lpSource,
        int dwMessageId, int dwLanguageId, ref String
        lpBuffer, int nSize, IntPtr* arguments);


        [DllImport("kernel32.dll", CharSet = CharSet.Auto,
SetLastError = true)]
        private static extern bool CloseHandle(IntPtr handle
        );

        [DllImport("advapi32.dll", CharSet = CharSet.Auto,
        SetLastError = true)]
        public extern static bool DuplicateToken(IntPtr
        existingTokenHandle,
        int SECURITY_IMPERSONATION_LEVEL, ref IntPtr
        duplicateTokenHandle);


        // logon types
        const int LOGON32_LOGON_INTERACTIVE = 2;
        const int LOGON32_LOGON_NETWORK = 3;
        const int LOGON32_LOGON_NEW_CREDENTIALS = 9;

        // logon providers
        const int LOGON32_PROVIDER_DEFAULT = 0;
        const int LOGON32_PROVIDER_WINNT50 = 3;
        const int LOGON32_PROVIDER_WINNT40 = 2;
        const int LOGON32_PROVIDER_WINNT35 = 1;

        private string userName;
        private string password;
        private string machineName;
        private string myDomain;

        private ManagementScope myScope;
        private ConnectionOptions connOptions;
        private ManagementObjectSearcher objSearcher;
        private ManagementOperationObserver opsObserver;
        bool logged = false;

        public SharingRights()
        {
            InitializeComponent();
            
        }

        public unsafe static string GetErrorMessage(int errorCode)
        {
            int FORMAT_MESSAGE_ALLOCATE_BUFFER = 0x00000100;
            int FORMAT_MESSAGE_IGNORE_INSERTS = 0x00000200;
            int FORMAT_MESSAGE_FROM_SYSTEM = 0x00001000;

            int messageSize = 255;
            string lpMsgBuf = "";
            int dwFlags = FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS;

            IntPtr ptrlpSource = IntPtr.Zero;
            IntPtr ptrArguments = IntPtr.Zero;

            int retVal = FormatMessage(dwFlags, ref ptrlpSource, errorCode, 0, ref lpMsgBuf, messageSize, &ptrArguments);
            if (retVal == 0)
            {
                throw new ApplicationException(string.Format("Failed to format message for error code '{0}'.", errorCode));
            }

            return lpMsgBuf;
        }

        private static void RaiseLastError()
        {
            int errorCode = Marshal.GetLastWin32Error();
            string errorMessage = GetErrorMessage(errorCode);

            throw new ApplicationException(errorMessage);
        }
        private void btnConnect_Click_1(object sender, EventArgs e)
        {
            if (txtMachineName.Text == string.Empty)
            {
                MessageBox.Show("Please select machine name");
                return;
            }
            ConnectMachine();
            

        }
        private void ConnectMachine()
        {
            userName = txtUserName.Text.Trim();
            password = txtPassword.Text.Trim();
            machineName = txtMachineName.Text.Trim();

            myDomain = "";
            try
            {
                connOptions = new ConnectionOptions();
                connOptions.Impersonation = ImpersonationLevel.Impersonate;
                connOptions.EnablePrivileges = true;
                if (machineName.ToUpper() == Environment.MachineName.ToUpper())
                {
                    myScope = new ManagementScope(@"\ROOT\CIMV2", connOptions);
                }

                else
                {
                    connOptions.Username = machineName + "\\" + userName;
                    connOptions.Password = password;
                    myScope = new ManagementScope(@"\\" + machineName + @"\ROOT\CIMV2", connOptions);
                }

                myScope.Connect();

                objSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;

                label2.Text = string.Empty;


                foreach (ManagementObject obj in objSearcher.Get())
                {
                    label2.Text = "Logged In To " + obj["csname"].ToString();
                    label6.Text = "Logged In";
                }

                objSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_Share");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;
                //String[] s = new String[10];
                foreach (ManagementObject obj in objSearcher.Get())
                {
                  
                    string[] s = new string[]{ obj["Name"].ToString() };
                    int len = s.Length;
                    if(!s[len-1].Contains("$"))
                    {
                    ListViewItem proc = new ListViewItem(s);
                    listView1.Items.Add(proc);
                    }
                }
                //set as logged in
                logged = true;
               
                fileBox.Text = "\\\\" + machineName + "\\" + "source1\\abc.txt";
                //userBox.Text = machineName + "\\\\" + "user1";

                /*
                 * Folder name format
                 * \\\\sandesh-pc\\source1
                 * 
                 * File name format
                 * \\sandesh-pc\source1\abc.txt
                 */


            }
               
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }

        }

       private void FileSec(String FilePath1, String account1, FileSystemRights fsr, AccessControlType act)    
        { 
           /// no escape characters required in filepath1
            userName = txtUserName.Text.Trim();
            password = txtPassword.Text.Trim();
            machineName = txtMachineName.Text.Trim();

            myDomain = "";
            try
            {
                //connOptions = new ConnectionOptions();
                //connOptions.Impersonation = ImpersonationLevel.Impersonate;
                //connOptions.EnablePrivileges = true;
                //    connOptions.Username = machineName + "\\" + userName;
                //    connOptions.Password = password;
                // FileSecurity fs = File.GetAccessControl(FilePath1);
            
                //fs.AddAccessRule(new FileSystemAccessRule(connOptions.Username,fsr,act));
                //File.SetAccessControl(FilePath1, fs);

                IntPtr token = IntPtr.Zero;
                IntPtr dupToken = IntPtr.Zero;

                bool isSuccess = LogonUser(userName,
                machineName, password,
                LOGON32_LOGON_NEW_CREDENTIALS,
                LOGON32_PROVIDER_DEFAULT, ref token);
                if (!isSuccess)
                {
                    RaiseLastError();
                }
                isSuccess = DuplicateToken(token, 2, ref dupToken);
                if (!isSuccess)
                {
                    RaiseLastError();
                }

                WindowsIdentity newIdentity = new WindowsIdentity(dupToken);
                WindowsImpersonationContext impersonatedUser = newIdentity.Impersonate();

              
                impersonatedUser.Undo();
              
                FileSecurity fs = File.GetAccessControl(FilePath1);
                //fs.AddAccessRule(new FileSystemAccessRule(account1, fsr, act));
                fs.AddAccessRule(new FileSystemAccessRule(newIdentity.User, fsr, act));
                File.SetAccessControl(FilePath1, fs);

                isSuccess = CloseHandle(token);
                if (!isSuccess)
                {
                    RaiseLastError();
                }
               
            }
           catch(Exception ex)
            {
               MessageBox.Show(ex.Message.ToString());
           }
                myScope.Connect();

           
            

            
        }
        
       
        private void DirSecurity(String dirName1, String account1, FileSystemRights fsr, AccessControlType act)
        {

            // escape characters required in dirname1
            String dirName = dirName1;
            String account = account1;
            FileSystemRights rights = fsr;
            AccessControlType controlType = act;
            

            //// Get a FileSecurity object that represents the current security settings.
            //DirectorySecurity dSecurity = dInfo.GetAccessControl();
            //dSecurity.AddAccessRule(new FileSystemAccessRule(account, rights, controlType));

            //// Set the new access settings.
            //dInfo.SetAccessControl(dSecurity);

            /// no escape characters required in filepath1
            userName = txtUserName.Text.Trim();
            password = txtPassword.Text.Trim();
            machineName = txtMachineName.Text.Trim();

            myDomain = "";
            try
            {
                //connOptions = new ConnectionOptions();
                //connOptions.Impersonation = ImpersonationLevel.Impersonate;
                //connOptions.EnablePrivileges = true;
                //    connOptions.Username = machineName + "\\" + userName;
                //    connOptions.Password = password;
                // FileSecurity fs = File.GetAccessControl(FilePath1);

                //fs.AddAccessRule(new FileSystemAccessRule(connOptions.Username,fsr,act));
                //File.SetAccessControl(FilePath1, fs);

                IntPtr token = IntPtr.Zero;
                IntPtr dupToken = IntPtr.Zero;

                bool isSuccess = LogonUser(userName,
                machineName, password,
                LOGON32_LOGON_NEW_CREDENTIALS,
                LOGON32_PROVIDER_DEFAULT, ref token);
                if (!isSuccess)
                {
                    RaiseLastError();
                }
                isSuccess = DuplicateToken(token, 2, ref dupToken);
                if (!isSuccess)
                {
                    RaiseLastError();
                }

                WindowsIdentity newIdentity = new WindowsIdentity(dupToken);
                WindowsImpersonationContext impersonatedUser = newIdentity.Impersonate();


                impersonatedUser.Undo();

                DirectoryInfo dInfo = new DirectoryInfo(dirName);
                DirectorySecurity fs = dInfo.GetAccessControl();
                //fs.AddAccessRule(new FileSystemAccessRule(account1, fsr, act));
                fs.AddAccessRule(new FileSystemAccessRule(newIdentity.User, rights, controlType));
                dInfo.SetAccessControl(fs);

                isSuccess = CloseHandle(token);
                if (!isSuccess)
                {
                    RaiseLastError();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            myScope.Connect();

   
        }

        

        private void ShareButton_Click_1(object sender, EventArgs e)
        {
            String fileName1 = fileBox.Text;
           
           
            String access = accessRightBox.Text;
            FileSystemRights fsr = FileSystemRights.Read;
            AccessControlType act = AccessControlType.Allow;
            if (access.Equals("Read"))
                fsr = FileSystemRights.Read;
            else if (access.Equals("Write"))
                fsr = FileSystemRights.Write;
            else if (access.Equals("FullControl"))
                fsr = FileSystemRights.FullControl;
            else if (access.Equals("Execute"))
                fsr = FileSystemRights.ExecuteFile;
            else if (access.Equals("List Directory"))
                fsr = FileSystemRights.ListDirectory;
            else MessageBox.Show("Invalid Choice ");

            if (permButton.Checked == true)
                act = AccessControlType.Allow;
            if (permButton1.Checked == true)
                act = AccessControlType.Deny;

           
                FileSec(fileName1, "ABC", fsr, act);
                label6.Text = " File Rights Changed successfully ";
                MessageBox.Show("File Rights Changed Successfully");

            
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void SharingRights_Load(object sender, EventArgs e)
        {

        }

        
        

        
    }
}
