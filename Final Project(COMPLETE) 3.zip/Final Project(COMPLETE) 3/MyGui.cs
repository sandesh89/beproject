﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinApp
{
    public partial class MyGui : Form
    {
        public MyGui()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProcessController pc = new ProcessController();
            pc.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RemoteDesktop rd = new RemoteDesktop();
            rd.Show();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            SharingRights sr = new SharingRights();
            sr.Show();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            BackupClient bak = new BackupClient();
            bak.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RemoteShutdown rs = new RemoteShutdown();
            rs.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            BlockWebSite bw = new BlockWebSite();
            bw.Show();
        }

        

        private void button8_Click(object sender, EventArgs e)
        {
            DisablePort dp = new DisablePort();
            dp.Show();
        }

       

        private void button10_Click(object sender, EventArgs e)
        {
            ListPcs lp = new ListPcs();
            lp.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ChangePassword cp = new ChangePassword();
            cp.Show();
        }

        
    }
}
