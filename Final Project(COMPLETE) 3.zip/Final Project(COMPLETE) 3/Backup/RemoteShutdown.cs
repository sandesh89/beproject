using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Management;
namespace WinApp
{
    public partial class RemoteShutdown : Form
    {
        public RemoteShutdown()
        {
            InitializeComponent();
        }

        private void RemoteShutdown_Load(object sender, EventArgs e)
        {
            
        }
        public static void Shutdown(string machineName, string username, string password) 
        { 
                ManagementScope Scope = null; 
                ConnectionOptions ConnOptions = null; 
                ObjectQuery ObjQuery = null; 
                ManagementObjectSearcher ObjSearcher = null; 
                try 
                { 
                        ConnOptions = new ConnectionOptions(); 
                        ConnOptions.Impersonation = ImpersonationLevel.Impersonate; 
                        ConnOptions.EnablePrivileges = true; 
                        //local machine 
                        if (machineName.ToUpper() == Environment.MachineName.ToUpper() ) 
                                Scope = new ManagementScope(@"\ROOT\CIMV2", ConnOptions); 
                        else 
                        { 
                        //remote machine 
                            ConnOptions.Username = username; 
                            ConnOptions.Password = password; 
                            Scope = new ManagementScope(@"\\" + machineName + @"\ROOT\CIMV2", ConnOptions); 
                        } 
                        Scope.Connect(); 
                        ObjQuery = new ObjectQuery("SELECT * FROM Win32_OperatingSystem"); 
                        ObjSearcher = new ManagementObjectSearcher(Scope, ObjQuery ); 
                        foreach( ManagementObject operatingSystem in ObjSearcher.Get()) 
                        { 
                                MessageBox.Show("Caption = " + operatingSystem.GetPropertyValue("Caption")); 
                                MessageBox.Show("Version = " + operatingSystem.GetPropertyValue("Version")); 
                                ManagementBaseObject outParams = operatingSystem.InvokeMethod ("Shutdown",null,null); 

                        } 
                    } 
                catch (Exception ex) 
                { 
                    throw ex; 
                } 

            }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            Shutdown(txtMachineName.Text.Trim(),txtUserName.Text.Trim(), txtPassword.Text.Trim());
        }
    }
}