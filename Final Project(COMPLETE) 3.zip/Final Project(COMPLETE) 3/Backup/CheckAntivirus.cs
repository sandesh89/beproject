using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using System.DirectoryServices;
using System.IO;

namespace WinApp
{
    public partial class CheckAntivirus : Form
    {
        private ManagementScope myScope;
        private ConnectionOptions connOptions;
        private ManagementObjectSearcher objSearcher;
        private ManagementOperationObserver opsObserver;
        private ManagementClass manageClass;
        private DirectoryEntry entry;
        private DirectorySearcher searcher;
        private DirectorySearcher userSearcher;
        public CheckAntivirus()
        {
            InitializeComponent();
        }

        private void CheckAntivirus_Load(object sender, EventArgs e)
        {
            
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string userName = "";
            string password = "";
            string machineName = "";
            userName = txtUserName.Text;
            password = txtPassword.Text;
            machineName = txtMachineName.Text;

            string myDomain = "";

            try
            {
                connOptions = new ConnectionOptions();
                connOptions.Impersonation = ImpersonationLevel.Impersonate;
                connOptions.EnablePrivileges = true;
                if (machineName.ToUpper() == Environment.MachineName.ToUpper())
                {
                    myScope = new ManagementScope(@"\root\SecurityCenter", connOptions);
                }
                else
                {

                    connOptions.Username = machineName + "\\" + userName;

                    connOptions.Password = password;
                    myScope = new ManagementScope(@"\\" + machineName + @"\root\SecurityCenter", connOptions);
                }

                myScope.Connect();
                objSearcher = new ManagementObjectSearcher("SELECT * FROM AntivirusProduct");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;
                ManagementObjectCollection _managementObjectCollection = objSearcher.Get();
                if (_managementObjectCollection.Count > 0)
                {
                    foreach (ManagementObject item in _managementObjectCollection)
                    {
                        lblAntivirusName.Text= item["displayName"].ToString();
                        if (item["productUptoDate"].ToString() == "True")
                        {
                            lblProductUpToDate.Text = "Yes";
                        }
                        else
                        {
                            lblProductUpToDate.Text = "No";
                        }
                        //If the value of ProductState is 266240 or 262144, its an updated one.         
                        lblCompanyName.Text= item["companyname"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

