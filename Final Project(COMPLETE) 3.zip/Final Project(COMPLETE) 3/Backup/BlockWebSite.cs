using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace WinApp
{
    public partial class BlockWebSite : Form
    {
        public BlockWebSite()
        {
            InitializeComponent();
        }

        private void BlockWebSite_Load(object sender, EventArgs e)
        {
           

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                //Settings.Permission to everyone all,Sharing/Security Add User Network,Interactive full permission
                String strpath = txtFileName.Text;
                StreamWriter objstrWri = new StreamWriter(strpath, true);
                String siteDtl = "\n 127.0.1 " + txtWebSiteName.Text;
                objstrWri.Write(siteDtl);
                objstrWri.Close();
                MessageBox.Show("WebSite blocked successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}