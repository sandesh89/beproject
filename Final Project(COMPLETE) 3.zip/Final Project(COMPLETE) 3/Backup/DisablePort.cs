using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using System.DirectoryServices;
using System.IO;

namespace WinApp
{
    public partial class DisablePort : Form
    {
        private ManagementScope myScope;
        private ConnectionOptions connOptions;
        private ManagementObjectSearcher objSearcher;
        private ManagementOperationObserver opsObserver;
        private ManagementClass manageClass;
        private DirectoryEntry entry;
        private DirectorySearcher searcher;
        private DirectorySearcher userSearcher;
        public DisablePort()
        {
            InitializeComponent();
        }

        private void DisablePort_Load(object sender, EventArgs e)
        {
            string userName = "";
            string password = "";
            string machineName = "";
            userName = "administrator";
            password ="qwerty";
            machineName = "webserver";

            string myDomain = "";

            try
            {
                connOptions = new ConnectionOptions();
                connOptions.Impersonation = ImpersonationLevel.Impersonate;
                connOptions.EnablePrivileges = true;
                if (machineName.ToUpper() == Environment.MachineName.ToUpper())
                {
                    myScope = new ManagementScope(@"\root\cimv2", connOptions);
                }
                else
                {

                    connOptions.Username = machineName + "\\" + userName;

                    connOptions.Password = password;
                    myScope = new ManagementScope(@"\\" + machineName + @"\root\cimv2", connOptions);
                }

                myScope.Connect();
                objSearcher = new ManagementObjectSearcher("Select * From Win32_USBControllerDevice");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;
                ManagementObjectCollection _managementObjectCollection = objSearcher.Get();
                string strDeviceName = "";
                
                if (_managementObjectCollection.Count > 0)
                {
                    foreach (ManagementObject item in _managementObjectCollection)
                    {
                        strDeviceName = item["dependent"].ToString();
                        strDeviceName = strDeviceName.Replace("\"", "");
                        string[] deviceNames = strDeviceName.Split('=');
                        strDeviceName = deviceNames[1];

                       ManagementObjectSearcher searcher2 = new ManagementObjectSearcher("Select * from Win32_PnPEntity where DeviceID = '" + strDeviceName + "'");
                       searcher2.Scope = myScope;
                       foreach(ManagementObject USBDevice in searcher2.Get())
                        {
                           
                            listBox1.Items.Add(USBDevice["PnPDeviceID"].ToString());
                            //MessageBox.Show(USBDevice["Description"].ToString() + " " +  USBDevice["PnPDeviceID"].ToString());
                          
                        }
                    

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}