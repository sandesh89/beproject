using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.DirectoryServices;

namespace WinApp
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void ChangePassword_Load(object sender, EventArgs e)
        {
           
        }
        public static void ResetPassword(string computerName, string username, string newPassword) 
        {
            try
            {
                DirectoryEntry directoryEntry = new DirectoryEntry(string.Format("WinNT://{0}/{1}", computerName, username));
                directoryEntry.Invoke("SetPassword", newPassword);
                MessageBox.Show("Password Changed Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            ResetPassword(txtMachineName.Text.Trim(),txtUserName.Text.Trim(),txtPassword.Text.Trim());
        } 
    }
}