﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Management;
using System.Windows.Forms;
using System.IO;
using System.Security;
using System.Diagnostics;

namespace WinApp
{
    public partial class BackupClient : Form
    {

        private string userName;
        private string password;
        private string machineName;
        private string myDomain;

        private ManagementScope myScope;
        private ConnectionOptions connOptions;
        private ManagementObjectSearcher objSearcher;
        private ManagementOperationObserver opsObserver;



        public BackupClient()
        {
            InitializeComponent();
            label6.Text = String.Empty;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (txtMachineName.Text == string.Empty)
            {
                MessageBox.Show("Please select machine name");
                return;
            }
            ConnectMachine();



        }
        private void ConnectMachine()
        {
            userName = txtUserName.Text.Trim();
            password = txtPassword.Text.Trim();
            machineName = txtMachineName.Text.Trim();

            myDomain = "";
            try
            {
                connOptions = new ConnectionOptions();
                connOptions.Impersonation = ImpersonationLevel.Impersonate;
                connOptions.EnablePrivileges = true;
                if (machineName.ToUpper() == Environment.MachineName.ToUpper())
                {
                    myScope = new ManagementScope(@"\ROOT\CIMV2", connOptions);
                }

                else
                {
                    connOptions.Username = machineName + "\\" + userName;
                    connOptions.Password = password;
                    myScope = new ManagementScope(@"\\" + machineName + @"\ROOT\CIMV2", connOptions);
                }

                myScope.Connect();

                objSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;

                label2.Text = string.Empty;


                foreach (ManagementObject obj in objSearcher.Get())
                {
                    label2.Text = "Logged In To " + obj["csname"].ToString();
                }

                bool Recursive = true;
                String SourcePath = SourceText.Text.Trim();
                String DestinationPath = DestText.Text.Trim();
                // label6.Text = SourcePath + " " + DestinationPath;
                //String SourcePath = "G:\\source1";
                //String DestinationPath = "G:\\dest1";
                objSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_Directory where Name=" + "\"" + SourcePath.Replace("\\", "\\\\") + "\"");
                opsObserver = new ManagementOperationObserver();
                objSearcher.Scope = myScope;
                try
                {
                    //foreach (ManagementObject dir in objSearcher.Get())
                    //{
                    //    //MessageBox.Show(dir["name"].ToString());
                    //    ManagementBaseObject inputArgs = dir.GetMethodParameters("CopyEx");
                    //    inputArgs["FileName"] = DestinationPath.Replace("\\", "\\\\");
                    //    inputArgs["Recursive"] = Recursive;
                    //    ManagementBaseObject outParams = dir.InvokeMethod("CopyEx", inputArgs, null);
                    //    MessageBox.Show(outParams["ReturnValue"].ToString());
                    //    //return ((uint)(outParams.Properties["ReturnValue"].Value));
                    //}

                    //label6.Text = " Successfully created backup!";
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message.ToString());
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //Note Is XCopy is not working the paste this line in environment variables %SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem 
                //CopyFolder(@"D:\dest1",@"\\Khushboo\C\Temp1\");
                string strcommand = @"\\" + txtMachineName.Text + @"\" + SourceText.Text + " " + DestText.Text + @" /e /y /I";
                Process process = new Process();
                try
                {

                process.StartInfo.FileName = "xcopy";
                //process.StartInfo.Arguments = @"\\khushboo\c\temp1 d:\dest1 /e /y /I";
                process.StartInfo.Arguments = strcommand;
                process.Start();
                bool lp = process.WaitForExit(10000);

                if(lp)
                process.Kill();
                }
                catch(Exception ex)
                {

                }
                finally
                {
                process.Close();
                label6.Text = " Successfully created backup!";
                }


                //System.Diagnostics.Process.Start("CMD.exe", "/c xcopy \\\\Khushboo\\C\\Temp1 D:\\dest1  /s");
                //ExecuteCommandSync(strcommand);



                //ExecuteCommandSync("xcopy '\\khushboo\C\Temp1' 
                //System.Diagnostics.Process.Start("CMD.exe",@"/C cd windows\system32 dir");
               // System.Diagnostics.Process.Start("CMD.exe",@"/C cd windows\system32");


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }
        public void ExecuteCommandSync(object command)
        {
            try
            {
                // create the ProcessStartInfo using "cmd" as the program to be run,
                // and "/c " as the parameters.
                // Incidentally, /c tells cmd that we want it to execute the command that follows,
                // and then exit.
                System.Diagnostics.ProcessStartInfo procStartInfo =
                    new System.Diagnostics.ProcessStartInfo("cmd", "/c " + command);

                // The following commands are needed to redirect the standard output.
                // This means that it will be redirected to the Process.StandardOutput StreamReader.
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                // Do not create the black window.
                procStartInfo.CreateNoWindow = true;
                // Now we create a process, assign its ProcessStartInfo and start it
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                // Get the output into a string
                string result = proc.StandardOutput.ReadToEnd();
                // Display the command output.
                MessageBox.Show(result);
            }
            catch (Exception objException)
            {
                // Log the exception
            }
        }
        private static void CopyFolder(string sourceFolder, string destFolder) 
{ 
            if (!Directory.Exists(destFolder)) 
                Directory.CreateDirectory(destFolder); 
                Process process1; 
                using (process1 = new Process()) 
                { 
                    process1.EnableRaisingEvents = true; 
                    string strcmd = sourceFolder + " " + destFolder + " /S"; 
                    process1.StartInfo.FileName = "xcopy"; 
                    process1.StartInfo.Arguments = strcmd; 
                   
                    process1.Start(); 
                } 
}

        private void BackupClient_Load(object sender, EventArgs e)
        {

        } 


    }
}
