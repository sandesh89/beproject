﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinApp
{
    public partial class ListPcs : Form
    {
        private Label lblNetworkComputers;
        private ListBox lstComputers;
    
       
        public ListPcs()
        {
            InitializeComponent();
            
        }

        

        private void InitializeComponent()
        {
            this.lblNetworkComputers = new System.Windows.Forms.Label();
            this.lstComputers = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblNetworkComputers
            // 
            this.lblNetworkComputers.AutoSize = true;
            this.lblNetworkComputers.Location = new System.Drawing.Point(12, 9);
            this.lblNetworkComputers.Name = "lblNetworkComputers";
            this.lblNetworkComputers.Size = new System.Drawing.Size(146, 13);
            this.lblNetworkComputers.TabIndex = 3;
            this.lblNetworkComputers.Text = "Available Network Computers";
            // 
            // lstComputers
            // 
            this.lstComputers.FormattingEnabled = true;
            this.lstComputers.Location = new System.Drawing.Point(15, 25);
            this.lstComputers.Name = "lstComputers";
            this.lstComputers.Size = new System.Drawing.Size(330, 264);
            this.lstComputers.TabIndex = 4;
            // 
            // ListPcs
            // 
            this.ClientSize = new System.Drawing.Size(368, 301);
            this.Controls.Add(this.lstComputers);
            this.Controls.Add(this.lblNetworkComputers);
            this.Name = "ListPcs";
            this.Load += new System.EventHandler(this.ListPcs_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void ListPcs_Load_1(object sender, EventArgs e)
        {
            //create a new NetworkBrowser object, and get the
            //list of network computers it found, and add each
            //entry to the combo box on this form
            try
            {
                NetworkBrowser nb = new NetworkBrowser();
                foreach (string pc in nb.getNetworkComputers())
                {
                    lstComputers.Items.Add(pc);
                    //cmbNetworkComputers.Items.Add(pc);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred trying to access the network computers", "error",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }
        
        
    }
}
