﻿namespace WinApp
{
    partial class SharingRights
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMachineName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.FolderName = new System.Windows.Forms.ColumnHeader();
            this.fileLabel = new System.Windows.Forms.Label();
            this.fileBox = new System.Windows.Forms.TextBox();
            this.permButton = new System.Windows.Forms.RadioButton();
            this.permButton1 = new System.Windows.Forms.RadioButton();
            this.Permissions = new System.Windows.Forms.GroupBox();
            this.accessRightBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ShareButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.Permissions.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtMachineName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtPassword);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtUserName);
            this.groupBox1.Location = new System.Drawing.Point(21, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(366, 189);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login box";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Not Logged In";
            // 
            // txtMachineName
            // 
            this.txtMachineName.Location = new System.Drawing.Point(159, 19);
            this.txtMachineName.Name = "txtMachineName";
            this.txtMachineName.Size = new System.Drawing.Size(198, 20);
            this.txtMachineName.TabIndex = 1;
            this.txtMachineName.Text = "sandesh-pc";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Machine Name/IP Address:";
            // 
            // btnConnect
            // 
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.Location = new System.Drawing.Point(159, 104);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(120, 23);
            this.btnConnect.TabIndex = 7;
            this.btnConnect.Text = "Log in";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Password:";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(159, 73);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '^';
            this.txtPassword.Size = new System.Drawing.Size(198, 20);
            this.txtPassword.TabIndex = 5;
            this.txtPassword.Text = "sandesh";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "User name:";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(159, 45);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(198, 20);
            this.txtUserName.TabIndex = 3;
            this.txtUserName.Text = "sandesh";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.FolderName});
            this.listView1.Location = new System.Drawing.Point(21, 253);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(223, 199);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // FolderName
            // 
            this.FolderName.Text = "Shared Folder ";
            this.FolderName.Width = 140;
            // 
            // fileLabel
            // 
            this.fileLabel.AutoSize = true;
            this.fileLabel.Location = new System.Drawing.Point(394, 67);
            this.fileLabel.Name = "fileLabel";
            this.fileLabel.Size = new System.Drawing.Size(54, 13);
            this.fileLabel.TabIndex = 5;
            this.fileLabel.Text = "File Name";
            // 
            // fileBox
            // 
            this.fileBox.Location = new System.Drawing.Point(476, 61);
            this.fileBox.Name = "fileBox";
            this.fileBox.Size = new System.Drawing.Size(121, 20);
            this.fileBox.TabIndex = 7;
            // 
            // permButton
            // 
            this.permButton.AutoSize = true;
            this.permButton.Location = new System.Drawing.Point(79, 19);
            this.permButton.Name = "permButton";
            this.permButton.Size = new System.Drawing.Size(50, 17);
            this.permButton.TabIndex = 10;
            this.permButton.TabStop = true;
            this.permButton.Text = "Allow";
            this.permButton.UseVisualStyleBackColor = true;
            // 
            // permButton1
            // 
            this.permButton1.AutoSize = true;
            this.permButton1.Location = new System.Drawing.Point(79, 51);
            this.permButton1.Name = "permButton1";
            this.permButton1.Size = new System.Drawing.Size(50, 17);
            this.permButton1.TabIndex = 11;
            this.permButton1.TabStop = true;
            this.permButton1.Text = "Deny";
            this.permButton1.UseVisualStyleBackColor = true;
            // 
            // Permissions
            // 
            this.Permissions.Controls.Add(this.permButton1);
            this.Permissions.Controls.Add(this.permButton);
            this.Permissions.Location = new System.Drawing.Point(397, 137);
            this.Permissions.Name = "Permissions";
            this.Permissions.Size = new System.Drawing.Size(200, 100);
            this.Permissions.TabIndex = 12;
            this.Permissions.TabStop = false;
            this.Permissions.Text = "Permissions";
            // 
            // accessRightBox
            // 
            this.accessRightBox.FormattingEnabled = true;
            this.accessRightBox.Items.AddRange(new object[] {
            "Read",
            "Write",
            "FullControl",
            "Execute",
            "List Directory"});
            this.accessRightBox.Location = new System.Drawing.Point(476, 94);
            this.accessRightBox.Name = "accessRightBox";
            this.accessRightBox.Size = new System.Drawing.Size(121, 21);
            this.accessRightBox.TabIndex = 13;
            this.accessRightBox.Text = "Read";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(394, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Access Rights";
            // 
            // ShareButton
            // 
            this.ShareButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShareButton.Location = new System.Drawing.Point(468, 256);
            this.ShareButton.Name = "ShareButton";
            this.ShareButton.Size = new System.Drawing.Size(129, 23);
            this.ShareButton.TabIndex = 15;
            this.ShareButton.Text = "Change Rights";
            this.ShareButton.UseVisualStyleBackColor = true;
            this.ShareButton.Click += new System.EventHandler(this.ShareButton_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(387, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = " Login First";
            // 
            // SharingRights
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 479);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ShareButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.accessRightBox);
            this.Controls.Add(this.Permissions);
            this.Controls.Add(this.fileBox);
            this.Controls.Add(this.fileLabel);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "SharingRights";
            this.Text = "SharingRights";
            this.Load += new System.EventHandler(this.SharingRights_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Permissions.ResumeLayout(false);
            this.Permissions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMachineName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader FolderName;
        private System.Windows.Forms.Label fileLabel;
        private System.Windows.Forms.TextBox fileBox;
        private System.Windows.Forms.RadioButton permButton;
        private System.Windows.Forms.RadioButton permButton1;
        private System.Windows.Forms.GroupBox Permissions;
        private System.Windows.Forms.ComboBox accessRightBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ShareButton;
        private System.Windows.Forms.Label label6;
    }
}