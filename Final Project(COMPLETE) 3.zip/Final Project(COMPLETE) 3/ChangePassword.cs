using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace WinApp
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void ChangePassword_Load(object sender, EventArgs e)
        {
           
        }
        public static void ResetPassword(string computerName, string username, string newPassword) 
        {
            try
            {
                DirectoryEntry directoryEntry = new DirectoryEntry(string.Format("WinNT://{0}/{1}", computerName, username));
                directoryEntry.Invoke("SetPassword", newPassword);
                MessageBox.Show("Password Changed Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        /*public void RSTPASS(string compname, string uname , string oldpass, string newpass)
        {
            try
            {

                PrincipalContext context = new PrincipalContext(ContextType.Machine, compname, uname, oldpass);
                UserPrincipal user = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, uname);
                user.ChangePassword(oldpass, newpass);
                MessageBox.Show("Password Changed Succesfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
         //  MessageBox.Show("Password Changed Succesfully");
        }
        */
        private void btnConnect_Click(object sender, EventArgs e)
        {
            ResetPassword(txtMachineName.Text.Trim(),txtUserName.Text.Trim(),NEWPassword.Text.Trim());
           // RSTPASS(txtMachineName.Text.Trim(),txtUserName.Text.Trim(),OLDPassword.Text.Trim(),NEWPassword.Text.Trim());
          //  RSTPASS("sandesh-pc", "user1", "user123", "sandesh");
        } 
    }
}